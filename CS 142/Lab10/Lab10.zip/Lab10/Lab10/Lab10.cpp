#include <iostream>
#include "Property.h"
#include <fstream>
#include <vector>
#include "Residential.h"
#include "Commercial.h"

using namespace std;

const string COMMERCIAL = "Commercial";
const string RESIDENTIAL = "Residential";
const int RENTAL_YES = 1;
const int RENTAL_NO = 0;
const int OCCUPIED = 1;
const int NOT_OCCUPIED = 0;
const int DISCOUNTED = 1;
const int NOT_DISCOUNTED = 0;


void Display_Properties(vector<Property*> all_property)
{

	for (int i = 0; i < all_property.size(); i++)
	{
		cout << all_property[i]->toString() << endl;
	}
}

void Load_File(vector<Property*> & all_property)
{
	cout << "Give me a file name please (remember to add the file extension): ";
	string file_name;

	cin.sync();
	getline(cin, file_name);
	
	ifstream property_import;
	property_import.open(file_name.c_str());
	
	if (property_import.is_open())
	{
		while (!property_import.eof())
		{
			stringstream ss;

			string line;
			getline(property_import, line);

			ss << line;

			string tag;
			int rental_status;
			string address;
			double value;
			int occupied_status;

			int discounted_status;
			double tax_discount;

			ss >> tag;

			if (tag == RESIDENTIAL)
			{
				if (ss >> rental_status >> value >> occupied_status && getline(ss, address))
				{
					Residential* newResidential = new Residential(occupied_status, tag, rental_status, value, address);

					all_property.push_back(newResidential);
				}
				else
				{
					cout << "Ignoring invalid properties in " << line << endl;
				}
			}
			else if (tag == COMMERCIAL)
			{
				if (ss >> rental_status >> value >> discounted_status >> tax_discount && getline(ss, address))
				{
					Commercial* newCommercial = new Commercial(discounted_status, tax_discount, tag, rental_status, value, address);

					all_property.push_back(newCommercial);
				}
				else
				{
					cout << "Ignoring invalid properties in " << line << endl;
				}
			}
			else
			{
				cout << "Ignoring invalid properties in " << line << endl;
			}
		}

		property_import.close();
	}
	else
	{
		cout << "That file doesn't exist." << endl;
	}
	cout << endl;
}

void Print_Tax_report(vector<Property*> all_property)
{
	cout << "\n\nNOW PRINTING TAX REPORT" << endl;
	
	for (int i = 0; i < all_property.size(); i++)
	{
		cout << "**Taxes due at property: " << all_property[i]->getAddress() << endl;
		cout << "\tProperty ID: " << all_property[i]->getPropID() << endl;
		cout << "\tEstimated Value: " << all_property[i]->getValue() << endl;
		cout << "\tEstimated Taxes Due: " << all_property[i]->getTaxes() << endl << endl;
	}
	
}

void Compute_Taxes(vector<Property*> all_properties)
{
	for (int i = 0; i < all_properties.size(); i++)
	{
		all_properties[i]->setTaxes();
	}
	
}

void Sort_Properties(vector<Property*>& all_properties, vector<Property*>& temp)
{

	
}

int main()
{
	vector<Property*> all_property;
	vector<Property*> temp;


	bool flag = true;
	while (flag)
	{
		cout << "\n\n-----------------------------------------\n";
		cout << "WELCOME TO JAKE'S AMAZING REAL ESTATE\n";
		cout << "-----------------------------------------";

		cout << "\n\n Do you want to: \n";
		cout << "1 - Display All Properties\n";
		cout << "2 - Inport Property From File and Calculate taxes\n";
		cout << "3 - Quit\n";

		cout << "\nPick and option: ";

		int option_selection;
		cin >> option_selection;

		if (!cin.fail())
		{
			if (option_selection == 1)
			{
				Display_Properties(all_property);
			}
			if (option_selection == 2)
			{				
				Load_File(all_property);
				Compute_Taxes(all_property);

				cout << "\nAll Valid Properties:" << endl;
				Display_Properties(all_property);
				Print_Tax_report(all_property);
			}

			if (option_selection == 3)
			{
				flag = false;
			}

		}
		else
		{
			cout << "That was an invalid option. Please select a valid option.";
			cin.clear();
			cin.ignore();
		}
	}
	return 0;
}