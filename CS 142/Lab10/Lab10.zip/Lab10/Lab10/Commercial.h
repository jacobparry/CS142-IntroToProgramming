#pragma once
#include "Property.h"
class Commercial :
	public Property
{
private:

	const int DISCOUNTED = 1;
	const int NOT_DISCOUNTED = 0;

	int discounted_status;
	double tax_discount;

	double non_rental_tax = .012;
	double rental_tax = .01;

public:
	Commercial(int discountStatus, double discount, string newTag, int rental, double newValue, string newAddress);
	~Commercial();

	/////GETTERS

	////SETTERS
	void setTaxes();
	/////GENERAL
	string toString();
};

